local plugin_label = 'magoogles_universal_rotation'

local gui             = require 'gui'
local spell_config    = require 'core.spell_config'
local spell_tracker   = require 'core.spell_tracker'
local rotation_engine = require 'core.rotation_engine'

local equipped_ids  = {}
local all_known_ids = {}
local all_known_set = {}

local scan_interval = 2.0
local last_scan     = -999

local settings = {
    scan_range  = 16.0,
    anim_delay  = 0.05,
    debug       = false,
}

local function is_enabled()
    if not gui.elements.enabled:get() then return false end
    if gui.elements.use_keybind:get() then
        local key   = gui.elements.keybind:get_key()
        local state = gui.elements.keybind:get_state()
        if key == 0x0A then return false end
        if state ~= 1 and state ~= true then return false end
    end
    return true
end

local function refresh_equipped()
    local now = get_time_since_inject()
    if now - last_scan < scan_interval then return end
    last_scan = now

    local ids = get_equipped_spell_ids()
    if not ids then equipped_ids = {}; return end

    equipped_ids = {}
    for _, id in ipairs(ids) do
        if id and id > 1 then
            table.insert(equipped_ids, id)
            if not all_known_set[id] then
                all_known_set[id] = true
                table.insert(all_known_ids, id)
            end
        end
    end
end

local function update_settings()
    settings.scan_range = gui.elements.scan_range:get()
    settings.anim_delay = gui.elements.anim_delay:get()
    settings.debug      = gui.elements.debug_mode:get()
    rotation_engine.set_scan_range(settings.scan_range)
end

local function _pretty_spell_name(raw)
    if not raw or raw == '' then return nil end
    raw = tostring(raw)
    local bracket = raw:match('%[([^%]]+)%]')
    if bracket and bracket ~= '' then raw = bracket end
    raw = raw:gsub('%s*ID%s*=%s*%d+.*$', '')
    raw = raw:gsub('[%[%]]', ''):gsub('^%s+', ''):gsub('%s+$', '')
    local parts = {}
    for p in raw:gmatch('[^_]+') do parts[#parts + 1] = p end
    if #parts >= 2 then table.remove(parts, 1) end
    local phrase = table.concat(parts, ' ')
    phrase = phrase:lower():gsub('(%a)([%w\']*)', function(a, b) return a:upper() .. b end)
    return phrase
end

local function render_overlay()
    if not is_enabled() then return end

    local sw = get_screen_width()
    local sh = get_screen_height()
    if not sw or not sh then return end

    local lp = get_local_player()
    if not lp then return end

    local x  = sw - 220
    local y  = 12
    local lh = 18
    local sz = 14

    local function line(text, col)
        graphics.text_2d(text, vec2:new(x, y), sz, col or color_white(220))
        y = y + lh
    end

    line('[ Universal Rotation ]', color_yellow(255))
    line(string.format('%d spells equipped', #equipped_ids), color_white(180))

    local shown = 0
    local spell_list = {}
    for _, spell_id in ipairs(equipped_ids) do
        if spell_id > 1 then
            local cfg = spell_config.get(spell_id)
            if cfg.enabled then
                table.insert(spell_list, { id = spell_id, cfg = cfg })
            end
        end
    end
    table.sort(spell_list, function(a, b) return a.cfg.priority < b.cfg.priority end)

    for _, entry in ipairs(spell_list) do
        if shown >= 6 then break end
        shown = shown + 1
        local id   = entry.id
        local name = _pretty_spell_name(get_name_for_spell(id)) or tostring(id)
        local ready = utility.is_spell_ready(id) and utility.is_spell_affordable(id)
        local on_cd = not spell_tracker.is_off_cooldown(id, entry.cfg.cooldown, entry.cfg.charges)

        local charges_left, charges_max = spell_tracker.get_charges(id, entry.cfg.charges)
        local charge_txt = ''
        if charges_max and charges_max > 1 then
            charge_txt = string.format(' %d/%d', charges_left, charges_max)
        end

        local label = string.format('[%d] %s%s', entry.cfg.priority, name:sub(1, 18), charge_txt)
        local col
        if not ready then
            col = color_red(200)
            label = label .. ' (N/A)'
        elseif on_cd then
            col = color_yellow(200)
            label = label .. ' (CD)'
        else
            col = color_green(255)
            label = label .. ' (RDY)'
        end
        line(label, col)
    end
end

on_update(function()
    refresh_equipped()
    update_settings()

    if not is_enabled() then return end

    local lp = get_local_player()
    if not lp then return end
    if lp:is_dead() then return end

    rotation_engine.tick(equipped_ids, settings)
end)

on_render_menu(function()
    gui.render(spell_config, equipped_ids, all_known_ids)
end)

on_render(function()
    render_overlay()
end)
