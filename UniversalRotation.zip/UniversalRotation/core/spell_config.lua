local plugin_label = 'magoogles_universal_rotation'

local spell_config = {}

local _elements = {}

local function key(spell_id, suffix)
    return plugin_label .. '_spell_' .. tostring(spell_id) .. '_' .. suffix
end

local function get_elements(spell_id)
    local id = tostring(spell_id)
    if _elements[id] then return _elements[id] end

    local e = {
        enabled      = checkbox:new(true,  get_hash(key(spell_id, 'enabled'))),
        priority     = slider_int:new(1, 10, 5, get_hash(key(spell_id, 'priority'))),
        cooldown     = slider_float:new(0.0, 5.0, 0.4, get_hash(key(spell_id, 'cooldown'))),
        charges      = slider_int:new(1, 5, 1, get_hash(key(spell_id, 'charges'))),
        elite_only   = checkbox:new(false, get_hash(key(spell_id, 'elite_only'))),
        boss_only    = checkbox:new(false, get_hash(key(spell_id, 'boss_only'))),
        min_enemies  = slider_int:new(0, 15, 0, get_hash(key(spell_id, 'min_enemies'))),
    }
    _elements[id] = e
    return e
end

function spell_config.render(spell_id, display_name)
    local e = get_elements(spell_id)
    e.enabled:render('Enable', 'Enable this spell in the rotation')
    if e.enabled:get() then
        e.priority:render('Priority (1=highest)', 'Lower number = cast first')
        e.cooldown:render('Min cooldown (s)', 'Minimum seconds between casts', 2)
        e.charges:render('Charges', 'Number of casts allowed before cooldown applies (1 = normal)', 3)
        e.elite_only:render('Elite / Champion only', 'Only cast against elites and champions')
        e.boss_only:render('Boss only', 'Only cast against bosses')
        e.min_enemies:render('Min enemies in range', 'Minimum enemies nearby to cast (0 = always)')
    end
end

function spell_config.get(spell_id)
    local e = get_elements(spell_id)
    return {
        enabled     = e.enabled:get(),
        priority    = e.priority:get(),
        cooldown    = e.cooldown:get(),
        elite_only  = e.elite_only:get(),
        boss_only   = e.boss_only:get(),
        min_enemies = e.min_enemies:get(),
        charges     = e.charges:get(),
    }
end

return spell_config
